require 'test_helper'

class EntriesHelperTest < ActionView::TestCase
end
