# coding: utf-8

class TopController < ApplicationController
  def index
  end

  def about
  end
end
