require 'test_helper'

class LessonControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
