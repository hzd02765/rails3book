# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Asagao::Application.config.secret_token = 'bdfa7a12f612168c95ed6b1be7ae5023c05952112e741a6a4752b08f2eca6a6e4d9d169365586e1ffec9340cd00ccec785dfee4ad291e2e85aaef4739e710944'
